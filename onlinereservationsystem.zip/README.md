# Online Reservation System

A Java-based train ticket reservation system using Swing and MySQL.